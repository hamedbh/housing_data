           Notes on the Supply of Ordnance Survey Digital Data
           ---------------------------------------------------

   Directory Structure
   -------------------

   The directory structure of this supplied data is shown below:

                        ROOT
                          |
                  -----------------
                 |                 |
                DOC              DATA

   The ROOT directory contains the following ASCII text files:
          o README.TXT - summary of supplied data 


   The DOC directory contains the following ASCII text files:

          o LICENCE.TXT - important licence information
          o CODELIST.XLS - lookup table of GSS Codes
          o NHS_CODELIST.XLS - lookup table of Health GSS Codes
          o METADATA.TXT - number of postcode units in each postcode area
          o Code-Point_Open_Column_Headers.csv - description of column headers 

 ------------------------------------- 

    

    

    