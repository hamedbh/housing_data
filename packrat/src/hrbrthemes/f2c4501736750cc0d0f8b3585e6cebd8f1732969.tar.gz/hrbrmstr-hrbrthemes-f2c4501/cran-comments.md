## Test environments

* local OS X install + travis-ci, R 3.3.2 & devel
* ubuntu 14.04 (on travis-ci), R oldrel, current, devel
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note (new pkg)

* This is a new release.

## Reverse dependencies

This is a new release, so there are no reverse dependencies.

---

* Full test suite (which ran within timings on win-builder) 
  w/100% code-coverage
* Vignette included